#' @title Read MusicXML
#'
#' @rdname readMusicXML
#' @export
#' @description Loads a MusicXML file.
#' @import XML
#'
#' @param file The MusicXML file.
#' @return A list containing a matrix with notes in midi format and the duration
#' of each note. Also gives the beat and beat type, the clef and the key of fifths.
#' @examples \dontrun{
#' training.melody <- readMusicXML(paste0(system.file(package = "MarkovMusic"), "/TrainingBlues.xml"))
#' training.melody
#' }

readMusicXML <- function(file) {
  song <- xmlInternalTreeParse(file)
  key.sign <- xpathSApply(song, "//attributes/clef/sign", xmlValue)
  key.line <- xpathSApply(song, "//attributes/clef/line", xmlValue)
  key.fifths <- xpathSApply(song, "//attributes/key/fifths", xmlValue)
  divisions <- as.numeric(xpathSApply(song, "//attributes/divisions", xmlValue))
  beat <- as.numeric(xpathSApply(song, "//attributes/time/beats", xmlValue))
  beat.type <- as.numeric(xpathSApply(song, "//attributes/time/beat-type", xmlValue))

  key.mat <- cbind(c("treble", "bass", "alto", "tenor"),
                   c("G2", "F4", "C3", "C4"))
  clef <- key.mat[key.mat[, 2] == paste0(key.sign, key.line), 1]
  midi.note <- data.frame(cbind(note = c("rest", "C", "D", "E", "F", "G", "A", "B")),
                          midi = c(-99, 0, 2, 4, 5, 7, 9, 11))
  midi.note$note <- as.character(midi.note$note)
  midi.note$midi <- as.numeric(midi.note$midi)

  pitch <- xpathSApply(song, "//note", function(x)
    if (xpathSApply(x, "boolean(./pitch)")) {
      xpathSApply(x, "./pitch/step", xmlValue)
    } else {
      "rest"
    }
  )
  octave <- xpathSApply(song, "//note", function(x)
    if (xpathSApply(x, "boolean(./pitch)")) {
      as.numeric(xpathSApply(x, "./pitch/octave", xmlValue))
    } else {
      1
    }
  )
  alter <- xpathSApply(song, "//note", function(x)
    if (xpathSApply(x, "boolean(./pitch/alter)")) {
      as.numeric(xpathSApply(x, "./pitch/alter", xmlValue))
    } else {
      0
    }
  )
  dur <- as.numeric(xpathSApply(song, "//note/duration", xmlValue))
  note <- sapply(pitch, function(x) midi.note[midi.note == x, 2]) + 12 * octave + 12 + alter
  note[pitch == "rest"] <- -99
  dur <- dur * 32/divisions

  result <- list(song = cbind(note = note, duration = dur),
                 beat = beat,
                 beat.type = beat.type,
                 clef = clef,
                 key.fifths = key.fifths)
  return(result)
}
