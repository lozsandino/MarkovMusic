#' @title Write Music XML
#'
#' @rdname writeMusicXML
#' @export
#' @description Writes a MusicXML file.
#' @import XML
#'
#' @param song A matrix with note, octave and duration.
#' @param file Name of the file to be written.
#' @param beat The beat.
#' @param beat.type The beat type.
#' @param clef Key of the song.
#' @param fifth Key signatures
#' @examples \dontrun{
#' melody <- cbind(note = TrainingBlues, octave = "5", duration = "16") # Same octave and duration.
#' writeMusicXML(melody, file = "test.xml", beat = 12, beat.type = 8)
#' }


writeMusicXML <- function(song, file = "MarkovMusic.xml",
                          beat = 4, beat.type = 4, clef = "treble", fifth = "0") {
  song <- noteMeasureFit(song, beat = beat, beat.type = beat.type)
  n <- nrow(song)
  bar.id <- as.numeric(song[, "measure"])
  m <- max(bar.id)

  key.mat <- cbind(c("treble", "bass", "alto", "tenor"),
                   c("G", "F", "C", "C"),
                   c("2", "4", "3", "4"))

  score.partwise <- newXMLNode("score-partwise")
  part.list <- newXMLNode("part-list", parent = score.partwise)
  score.part <- newXMLNode("score-part", attrs = c(id = "P1"), parent = part.list)
  part.name <- newXMLNode("part-name", "Music", parent = score.part)
  part <- newXMLNode("part", attrs = c(id = "P1"), parent = score.partwise)
  measure.list <- list()
  attributes <- newXMLNode("attributes")
  divisions <- newXMLNode("divisions", 32, parent = attributes)
  key <- newXMLNode("key", parent = attributes)
  fifths <- newXMLNode("fifths", fifth, parent = key)
  time <- newXMLNode("time", parent = attributes)
  b <- newXMLNode("beats", beat, parent = time)
  bt <- newXMLNode("beat-type", beat.type, parent = time)
  clf <- newXMLNode("clef", parent = attributes)
  sg <- newXMLNode("sign", key.mat[key.mat[, 1] == clef, 2], parent = clf)
  ln <- newXMLNode("line", key.mat[key.mat[, 1] == clef, 3], parent = clf)

  notes.in.bar <- as.vector(table(bar.id))
  k <- 1
  t <- FALSE
  notation.need <- FALSE
  tie.list <- list()
  h <- 1
  for (i in 1:m) {
    bar <- newXMLNode("measure", attrs = c(number = i))
    if (i == 1) {
      bar <- addChildren(bar, kids = list(attributes))
    }
    note.list <- list()
    for (j in 1:notes.in.bar[i]) {
      note <- newXMLNode("note")

      if (song[k, "step"] == "rest") {
        rest <- newXMLNode("rest", parent = note)
        dur <- newXMLNode("duration", song[k, "duration"], parent = note)
        type <- newXMLNode("type", song[k, "type"], parent = note)
        k <- k + 1
      } else {
        pitch <- newXMLNode("pitch", parent = note)
        if (nchar(song[k, "step"]) == 2) {
          step <- newXMLNode("step", unlist(strsplit(song[k, "step"], ""))[1], parent = pitch)
          alter <- newXMLNode("alter", "-1", parent = pitch)
          octave <- newXMLNode("octave", song[k, "octave"], parent = pitch)
          dur <- newXMLNode("duration", song[k, "duration"], parent = note)
          if (t) {
            t1 <- newXMLNode("tie", attrs = c(type = "stop"), parent = note)
            tie.list[[1]] <- newXMLNode("tied", attrs = c(type = "stop"))
            h <- 2
            notation.need <- TRUE
          }
          if (song[k, "tie"]) {
            t1 <- newXMLNode("tie", attrs = c(type = "start"), parent = note)
            tie.list[[h]] <- newXMLNode("tied", attrs = c(type = "start"))
            t <- TRUE
            h <- 1
            notation.need <- TRUE
          }
          type <- newXMLNode("type", song[k, "type"], parent = note)
          accidental <- newXMLNode("accidental", "flat", parent = note)
          if (notation.need) {
            notations <- newXMLNode("notations", parent = note)
            notations <- addChildren(notations, kids <- tie.list)
            notation.need <- FALSE
            tie.list <- list()
          }
          k <- k +1
        } else {
          step <- newXMLNode("step", song[k, "step"], parent = pitch)
          octave <- newXMLNode("octave", song[k, "octave"], parent = pitch)
          dur <- newXMLNode("duration", song[k, "duration"], parent = note)
          if (t) {
            t1 <- newXMLNode("tie", attrs = c(type = "stop"), parent = note)
            tie.list[[1]] <- newXMLNode("tied", attrs = c(type = "stop"))
            h <- 2
            notation.need <- TRUE
          }
          if (song[k, "tie"]) {
            t1 <- newXMLNode("tie", attrs = c(type = "start"), parent = note)
            tie.list[[h]] <- newXMLNode("tied", attrs = c(type = "start"))
            t <- TRUE
            h <- 1
            notation.need <- TRUE
          }
          type <- newXMLNode("type", song[k, "type"], parent = note)
          if (notation.need) {
            notations <- newXMLNode("notations", parent = note)
            notations <- addChildren(notations, kids <- tie.list)
            notation.need <- FALSE
            tie.list <- list()
          }
          k <- k + 1
        }
      }
      note.list[[j]] <- note
    }
    bar <- addChildren(bar, kids = note.list)
    note.list <- list()
    measure.list[[i]] <- bar
  }
  part <- addChildren(part, kids = measure.list)

  saveXML(score.partwise, file = file)
}
