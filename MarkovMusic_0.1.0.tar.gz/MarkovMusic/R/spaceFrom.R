#' @title spaceFrom
#'
#' @description Generates all posible combinations of elements of the
#' state spaces, creating a prefix space.
#'
#' @param state.space A vector of common state spaces among processes.
#' @param order The order of the Markov process.
#' @return A vector with all posible combinations of the state space,
#' of the same size of the order.

spaceFrom <- function(state.space, order = 2) {
  k <- length(state.space)
  result <- state.space
  if (order > 1) {
    for (i in 1:(order - 1)) {
      result <- rep(result, k)
      result <- paste(rep(state.space, each = length(result)/k), result, sep = "/")
    }
  }
  return(result)
}
