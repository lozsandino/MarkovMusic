#' @title Notes fitted to a certain measure.
#'
#' @description Fits a song to a certain measure structure.
#'
#' @param song A matrix with note, octave and duration.
#' @param beat The beat.
#' @param beat.type The beat type.
#' @return A dataframe with note, duration, octave, duration and its
#' corresponding measure.

noteMeasureFit <- function(song, beat = 4, beat.type = 4) {
  dur <- c(1, 2, 4, 8, 16, 32, 64, 128)
  type <- c("128th", "64th", "32nd", "16th", "eighth", "quarter", "half", "whole")
  n <- nrow(song)
  duration <- as.numeric(song[, "duration"])
  song <- as.matrix(song[, -3])

  results <- matrix(ncol = 6)
  colnames(results) <- c("step", "octave", "duration", "type", "measure", "tie")

  max.time <- beat/beat.type * 128
  cum.time <- 0
  measure <- 1
  j <- 1
  for (i in 1:n) {
    d <- duration[i]
    if (d + cum.time <= max.time) {
      while (d != 0) {
        m <- which.min((d - dur)[d - dur >= 0])
        tie <- min((d - dur)[d - dur >= 0]) != 0
        results <- rbind(results,
                         c(song[i, 1], song[i, 2], dur[m], type[m], measure, tie))
        j <- j + 1
        d <- d - dur[m]
        cum.time <- cum.time + dur[m]
        if (cum.time == max.time) {
          measure <- measure + 1
          cum.time <- 0
        }
      }
    }
    if (d + cum.time > max.time) {
      d1 <- max.time - cum.time
      d2 <- d + cum.time - max.time
      while (d1 != 0) {
        m <- which.min((d1 - dur)[d1 - dur >= 0])
        tie <- TRUE
        results <- rbind(results,
                         c(song[i, 1], song[i, 2], dur[m], type[m], measure, tie))
        j <- j + 1
        d1 <- d1 - dur[m]
        cum.time <- cum.time + dur[m]
        if (cum.time == max.time) {
          measure <- measure + 1
          cum.time <- 0
        }
      }
      while (d2 != 0) {
        m <- which.min((d2 - dur)[d2 - dur >= 0])
        tie <- min((d2 - dur)[d2 - dur >= 0]) != 0
        results <- rbind(results,
                         c(song[i, 1], song[i, 2], dur[m], type[m], measure, tie))
        j <- j + 1
        d2 <- d2 - dur[m]
        cum.time <- cum.time + dur[m]
        if (cum.time == max.time) {
          measure <- measure + 1
          cum.time <- 0
        }
      }
    }
  }
  results <- results[-1, ]
  return(results)
}
