#' @title Training Blues melody
#'
#' @description A 528 note melody in minor C blues scale.
#' @name TrainingBlues
#' @docType data
#' @usage  TrainingBlues
#' @format A vector of notes in English notation.
NULL
