#' @title Melody Generation.
#'
#' @rdname genMelody
#' @export
#' @description Generates sequence of notes using Markov processes.
#' @import stats
#'
#' @param proc A list of transition matrices, these being uncostrained (M)
#' or constrained (Z), belonging to a single or multiple processes.
#' @param state.space A vector of common state spaces among processes.
#' @param duration The duration of all notes.
#' @return A matrix with note, octave and duration.
#' @examples
#' Cm <- TrainingBlues
#' M0Cm <- priorVec(Cm, state.space = unique(Cm))
#' M1Cm <- transMat(Cm, state.space = unique(Cm))
#' M2Cm <- transMat(Cm, order = 2, state.space = unique(Cm))
#' M <- c(list(M0Cm), list(M1Cm), rep(list(M2Cm), 46))
#'
#' # Melody generation.
#' set.seed(69)
#' genMelody(M, state.space = unique(Cm))

genMelody <- function(proc, state.space, duration = 16) {
  n <- length(proc)
  k <- length(state.space)

  melody <- rep(NA, n)
  state <- rmultinom(1, 1, proc[[1]])
  melody[1] <- state.space[as.logical(state)]
  prefix <- melody[1]
  for (i in 2:n) {
    probs <- proc[[i]][rownames(proc[[i]]) == prefix, ]
    state <- rmultinom(1, 1, probs)
    melody[i] <- state.space[as.logical(state)]
    if (i < n) {
      q <- nrow(proc[[i + 1]])
      prefix <- paste(melody[(i + 1 - log(q)/log(k)):i], collapse = "/")
    }
  }
  melody <- fromNoteToMidi(melody)
  melody <- fromMidiToNote(melody, octave = T)
  melody <- cbind(melody, duration = duration)
  return(melody)
}
