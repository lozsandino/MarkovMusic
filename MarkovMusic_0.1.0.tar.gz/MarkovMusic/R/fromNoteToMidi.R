#' @title Note to MIDI.
#'
#' @description Converts a vector of notes in English notation to MIDI notation.
#'
#' @param melody Vector of notes in English notation.
#' @param min.oct Minimum octave of the note-to-MIDI conversion.
#' @param max.oct Maximum octave of the note-to-MIDI conversion.
#' @param d The number of precious notes to be considered in the
#' octave approximation.
#' @return A vector of MIDI notes.


fromNoteToMidi <- function(melody, min.oct = 3, max.oct = 6, d = 1) {
  notes <- c("C", "Db", "D", "Eb", "E", "F", "Gb", "G", "Ab", "A", "Bb", "B")
  octaves <- c(-1, 0, 1, 2, 3, 4, 5, 6, 7, 8)
  midi <- 0:119
  midi.mat <- matrix(midi, ncol = length(octaves))
  rownames(midi.mat) <- notes
  colnames(midi.mat) <- octaves
  octave <- floor((min.oct + max.oct)/2)
  midi.mat <- midi.mat[, colnames(midi.mat) %in% seq(min.oct, max.oct)]

  n <- length(melody)
  new.melody <- rep(-99, n)

  if (melody[1] %in% notes) {
    new.melody[1] <- midi.mat[rownames(midi.mat) == melody[1], colnames(midi.mat) == octave]
  } else {
    last.d <- midi.mat[rownames(midi.mat) == "F", colnames(midi.mat) == octave]
  }

  for (i in 2:n) {
    if(melody[i] == "rest") {
      next
    }
    if (any(new.melody != -99)) {
      last.d <- new.melody[new.melody != -99]
      k <- length(last.d)
      last.d <- mean(last.d[max(1, k - d):k])
    }
    new.note <- midi.mat[rownames(midi.mat) == melody[i], ]
    new.melody[i] <- new.note[which.min((new.note - last.d)^2)]
  }
  names(new.melody) <- melody
  return(new.melody)
}
