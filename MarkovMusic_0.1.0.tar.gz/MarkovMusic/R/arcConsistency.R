#' @title Arc-Consistency
#'
#' @rdname arcConsistency
#' @export
#' @description Produces arc-consistency over an uncosntrained list of
#' transition matrices M.
#'
#' @param M a list of transition matrices. Each matrix accounts for each t,
#' with 1 < t < L. It may also contain the prior vector.
#' @param constraints A list of constraints. Each of its elements is a list,
#' with the first element of that list being the value of t in which the
#' process is to be constrained, and the second is a vector containing the
#' desired state or states to be generated at that t.
#' @return A list of transition matrices with arc-consistency, similar to
#' the Z tilde processes but unnormalized. Normalization is not necessary
#' since the rmultinom function normalizes the probability vector.
#' @examples
#' Cm <- TrainingBlues
#' M0Cm <- priorVec(Cm, state.space = unique(Cm))
#' M1Cm <- transMat(Cm, state.space = unique(Cm))
#' M2Cm <- transMat(Cm, order = 2, state.space = unique(Cm))
#' M <- c(list(M0Cm), list(M1Cm), rep(list(M2Cm), 46))
#'
#' # Constraints.
#' constraints <-  list(list(2, c("C", "F")), # Second note must be either C or F.
#'                      list(48, "C")) # Last note must be C.
#'
#' # Arc-Consistency.
#' Z <- arcConsistency(M, constraints)
#'
#' # Constrained melody generation.
#' set.seed(69)
#' genMelody(Z, state.space = unique(Cm))


arcConsistency <- function(M, constraints) {
  q <- length(constraints)
  n <- length(M)
  L <- c()

  for (j  in 1:q) {
    L <- c(L, constraints[[j]][[1]])
    t <- constraints[[j]][[1]]
    M[[t]][, !(colnames(M[[t]]) %in% constraints[[j]][[2]])] <- 0
  }

  t <- L[q]
  i <- q
  k <- ncol(M[[1]])
  while (t > 2 & i > 0) {
    x0 <- as.numeric(rowSums(M[[t]]) > 0)
    x <- matrix(x0, ncol = k, byrow = TRUE)
    row.prev <- nrow(M[[t - 1]])
    row.x <- nrow(x)
    x <- do.call(rbind, replicate(row.prev/row.x, x, simplify = FALSE))
    y0 <- as.numeric(rowSums(M[[t - 1]]) > 0)
    M[[t - 1]] <- M[[t - 1]] * x
    y1 <- as.numeric(rowSums(M[[t - 1]]) > 0)
    if (sum(y1) == 0) {
      stop("Constraints cannot be achieved. Try more flexible constraints.")
    }
    if (all(y1 == y0)) {
      i <- i - 1
      t <- L[i]
    } else {
      t <- t - 1
    }
  }

  t <- L[1]
  i <- 1
  while (t < n &  i < q + 1) {
    x <- M[[t]]
    x <- as.numeric(colSums(x) > 0)
    row.next <- nrow(M[[t + 1]])
    row.x <- length(x)
    x <- rep(x, row.next/row.x)
    y0 <- as.numeric(rowSums(M[[t + 1]]) > 0)
    M[[t + 1]] <- M[[t + 1]] * x
    y1 <- as.numeric(rowSums(M[[t + 1]]) > 0)
    if (all(y1 == y0)) {
      i <- i + 1
      t <- L[i]
    } else {
      t <- t + 1
    }
  }

  return(M)
}
