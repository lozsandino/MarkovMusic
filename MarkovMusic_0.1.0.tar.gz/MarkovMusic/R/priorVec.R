#' @title Prior Vector
#'
#' @rdname priorVec
#' @export
#' @description Creates a vector of relative frequencies to use as a
#' prior vector to initiate the sequence.
#' @import stats
#'
#' @param melodies A vector corresponding to the training melody.
#' @param state.space A vector of common state spaces among processes.
#' @return A vector of relative frequencies corresponding to the
#' prior probabilities.
#' @examples
#' Cm <- TrainingBlues
#' M0Cm <- priorVec(Cm, state.space = unique(Cm))
#' M0Cm

priorVec <- function(melodies, state.space = NULL) {
  if (!is.list(melodies)) {
    melodies <- list(melodies)
  }
  n <- length(melodies)

  if (is.null(state.space)) {
    state.space <- unique(unlist(melodies))
  }
  space <- c()
  if (is.null(state.space)) {
    for (k in 1:n) {
      space <- c(space, melodies[[k]])
    }
  } else {
    space <- state.space
  }
  M <- rep(0, length(unique(space)))
  for (k in 1:n) {
    x <- factor(melodies[[k]], levels = unique(space))
    M <- M + as.vector(xtabs(~ x))
  }
  M <- M/sum(M)
  names(M) <- unique(space)

  return(t(as.matrix(M, nrow = 1)))
}
