#' @title Transition Matrix.
#'
#' @rdname transMat
#' @export
#' @description Creates the transition matrix of a certain order using
#' a training melody.
#' @import stats
#'
#' @param melodies A vector corresponding to the training melody.
#' @param order The order of the matrix.
#' @param state.space A vector of common state spaces among processes.
#' @return A matrix of transition probabilities. It may be non-stochastic.
#' @examples
#' Cm <- TrainingBlues
#' state.space <- c(unique(Cm), c("Ab", "B")) # includes other states from Fm.
#' M2Cm <- transMat(Cm, order = 2, state.space = state.space) # Second order transition matrix.
#' M2Cm


transMat <- function(melodies, order = 1, state.space = NULL) {
  if (!is.list(melodies)) {
    melodies <- list(melodies)
  }

  # State space and prefix space.
  if (is.null(state.space)) {
    state.space <- unique(unlist(melodies))
  }
  from <- spaceFrom(state.space, order = order)

  if (order >= 1) {
    n <- length(melodies) # Number of melodies.
    for (k in 1:n) {
      x <- melodies[[k]]
      m <- length(x)
      y <- x

      if (m <= order) {
        stop("Training melodies are shorter than the order")
      }

      i <- 1
      while (i < order) {
        y <- paste(x[-(m - i + 1)], y[-1], sep = "/")
        i <- i + 1
      }
      melodies[[k]] <- cbind(y[-((m - i + 1):m)], x[-(1:i)])
    }
  }

  # Transition Matrix.
  M <- matrix(0, nrow = length(from), ncol = length(state.space))
  for (k in 1:n) {
    y <- factor(melodies[[k]][, 1], levels = from)
    x <- factor(melodies[[k]][, 2], levels = state.space)
    M <- M + xtabs(~ y + x)
  }
  M <- M/rowSums(M)
  M[!complete.cases(M), ] <- 0

  return(M)
}
