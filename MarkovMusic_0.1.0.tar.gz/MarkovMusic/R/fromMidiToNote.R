#' @title MIDI to Note.
#'
#' @rdname fromMidiToNote
#' @export
#' @description Converts a vector of notes in MIDI notation to English notation.
#'
#' @param melody Vector of notes in MIDI notation.
#' @param octave Indicates whether information of the octave should be included.
#' @return If octave = FALSE, vector of notes in English notation. Else a
#' dataframe of notes in English notation and its corresponding octave.
#' @examples \dontrun{
#' training.melody <- readMusicXML(paste0(system.file(package = "MarkovMusic"), "/TrainingBlues.xml"))
#' Cm <- c(training.melody, rev(training.melody))
#' Cm
#' Cm <- fromMidiToNote(Cm)
#' Cm
#' }

fromMidiToNote <- function(melody, octave = FALSE) {
  notes <- c("C", "Db", "D", "Eb", "E", "F", "Gb", "G", "Ab", "A", "Bb", "B")
  octaves <- c(-1, 0, 1, 2, 3, 4, 5, 6, 7, 8)
  midi <- 0:120
  note.table <- cbind(note = rep(notes, 10),
                      octave = rep(octaves, each = 12))
  note.table <- rbind(note.table, c("rest", ""))
  melody[names(melody) == "rest"] <- 120
  note.oct <- note.table[midi = melody + 1, ]

  if (!octave) {
    note.oct <- note.oct[, 1]
  }

  return(note.oct)
}
